﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CodeBlooded.Models;
using System.Reflection;

namespace CodeBlooded.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    private readonly CodeBloodedDbContext _context;

    public HomeController(ILogger<HomeController> logger, CodeBloodedDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Account()
    {
        return View();
    }

    public IActionResult Volunteers()
    {
        var allVolunteers = _context.Volunteer.ToList(); //Goes to DB and gets all items and puts into list

        return View(allVolunteers); //Shows the list on the view
    }

    public IActionResult CreateEditVolunteer(int? id)
    {
        if (id != null)
        {
            //editing -> load an expense by id
            var volunteerInDb = _context.Volunteer.SingleOrDefault(volunteer => volunteer.Id == id);
            return View(volunteerInDb);
        }

        return View();
    }

    public IActionResult DeleteVolunteer(int id)
    {
        var volunteerInDb = _context.Volunteer.SingleOrDefault(volunteer => volunteer.Id == id); //find where an id in the Db matches the given id

        _context.Volunteer.Remove(volunteerInDb); //remove that expense from the DB

        _context.SaveChanges();

        return RedirectToAction("Volunteers");
    }

    public IActionResult CreateEditVolunteerForm(Volunteers model)
    {
        if (model.Id == 0)
        {
            //Create
            _context.Volunteer.Add(model);
        }
        else
        {
            //Editing
            _context.Volunteer.Update(model);
        }

        _context.SaveChanges(); //Must be done or else statement above doesnt work

        return RedirectToAction("Volunteers");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}


﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CodeBlooded.Models;
using System.Linq;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Threading.Tasks;
using System.Security.Principal;

namespace CodeBlooded.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly CodeBloodedDbContext _context;

        public HomeController(ILogger<HomeController> logger, CodeBloodedDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Account(Account account)
        {
            const string validUsername = "admin";
            const string validPassword = "password";

            if (account.Username == validUsername && account.Password == validPassword)
            {
                HttpContext.Session.SetString("Username", account.Username);
                return View("Account");
            }
            else
            {
                ViewData["ErrorMessage"] = "Invalid username or password. Please try again.";
                return View("Index", account);
            }
        }

        public IActionResult Volunteers(string searchText)
        {
            var volunteers = _context.Volunteer.AsQueryable();

            if (!string.IsNullOrEmpty(searchText))
            {
                searchText = searchText.ToLower();
                volunteers = volunteers.Where(v => v.FirstName.ToLower().Contains(searchText)
                                                || v.LastName.ToLower().Contains(searchText)
                                                || v.Username.ToLower().Contains(searchText));
            }

            var volunteerList = volunteers.ToList();
            ViewData["SearchText"] = searchText;

            if (!volunteerList.Any() && !string.IsNullOrEmpty(searchText))
            {
                ViewData["NoResultsMessage"] = "No volunteers found matching the search criteria.";
            }

            return View(volunteerList);
        }

        public IActionResult filterVolunteer(string input)
        {
            var filteredVolunteers = _context.Volunteer.ToList();

            switch (input)
            {
                case "All":
                    break;
                case "Approved":
                case "Pending Approval":
                case "Disapproved":
                case "Inactive":
                    filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
                    break;
                case "Approved/Pending Approval":
                    filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == "Approved" || volunteer.Status == "Pending Approval").ToList();
                    break;
            }

            return View("Volunteers", filteredVolunteers);
        }

        public IActionResult CreateEditVolunteer(int? id)
        {
            Volunteers volunteer;

            if (id.HasValue)
            {
                volunteer = _context.Volunteer.SingleOrDefault(v => v.Id == id);
                if (volunteer == null)
                {
                    return NotFound();
                }
            }
            else
            {
                volunteer = new Volunteers();
            }

            return View(volunteer);
        }

        [HttpPost]
        public IActionResult CreateEditVolunteerForm(Volunteers model)
        {
            if (!ModelState.IsValid)
            {
                return View("CreateEditVolunteer", model);
            }

            if (model.Id == 0)
            {
                _context.Volunteer.Add(model);
            }
            else
            {
                var volunteerInDb = _context.Volunteer.SingleOrDefault(v => v.Id == model.Id);

                if (volunteerInDb == null)
                {
                    return NotFound();
                }

                volunteerInDb.FirstName = model.FirstName;
                volunteerInDb.LastName = model.LastName;
                volunteerInDb.Username = model.Username;
                volunteerInDb.Password = model.Password;
                volunteerInDb.PreferredCenters = model.PreferredCenters;
                volunteerInDb.SkillsInterests = model.SkillsInterests;
                volunteerInDb.AvailabilityTimes = model.AvailabilityTimes;
                volunteerInDb.Address = model.Address;
                volunteerInDb.HomePhone = model.HomePhone;
                volunteerInDb.WorkPhone = model.WorkPhone;
                volunteerInDb.CellPhone = model.CellPhone;
                volunteerInDb.Email = model.Email;
                volunteerInDb.EducationalBackground = model.EducationalBackground;
                volunteerInDb.CurrentLicenses = model.CurrentLicenses;
                volunteerInDb.EmergencyContactName = model.EmergencyContactName;
                volunteerInDb.EmergencyContactHomePhone = model.EmergencyContactHomePhone;
                volunteerInDb.EmergencyContactWorkPhone = model.EmergencyContactWorkPhone;
                volunteerInDb.EmergencyContactEmail = model.EmergencyContactEmail;
                volunteerInDb.EmergencyContactAddress = model.EmergencyContactAddress;
                volunteerInDb.DriversLicenseOnFile = model.DriversLicenseOnFile;
                volunteerInDb.SocialSecurityCardOnFile = model.SocialSecurityCardOnFile;
                volunteerInDb.Status = model.Status;
            }

            _context.SaveChanges();

            return RedirectToAction("Volunteers");
        }

        public IActionResult DeleteVolunteer(int id)
        {
            var volunteerInDb = _context.Volunteer.SingleOrDefault(v => v.Id == id);

            if (volunteerInDb == null)
            {
                return NotFound();
            }

            _context.Volunteer.Remove(volunteerInDb);
            _context.SaveChanges();

            return RedirectToAction("Volunteers");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult CancelCreateEditVolunteer()
        {
            return RedirectToAction("Index");
        }

        public IActionResult Opportunities()
        {
            var allOpportunities = _context.Opportunities.ToList();
            return View(allOpportunities);
        }
    }
}

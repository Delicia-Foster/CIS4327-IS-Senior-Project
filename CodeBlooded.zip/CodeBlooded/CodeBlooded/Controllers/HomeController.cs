﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CodeBlooded.Models;
using System.Reflection;

namespace CodeBlooded.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Account(string username, string password)
    {
        // Save username and password to the session
        HttpContext.Session.SetString("UserName", username);
        HttpContext.Session.SetString("Password", password);

        return View();
    }

    public IActionResult Volunteers()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}


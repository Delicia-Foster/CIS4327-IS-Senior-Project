﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using CodeBlooded.Models;
using System.Reflection;

namespace CodeBlooded.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    private readonly CodeBloodedDbContext _context;

    public HomeController(ILogger<HomeController> logger, CodeBloodedDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Account()
    {
        return View();
    }

    public IActionResult filterVolunteer(string input)
    {
        // Filter products based on category and price range
        var filteredVolunteers = _context.Volunteer.ToList();

        if (input.Equals("All"))
        {
            return View("Volunteers", filteredVolunteers);
        }
        else if (input.Equals("Approved"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }
        else if (input.Equals("Pending Approval"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }
        else if (input.Equals("Disapproved"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }
        else if (input.Equals("Inactive"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }
        else
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => (volunteer.Status == "Approved" || (volunteer.Status == "Pending Approval"))).ToList();
        }
            // Pass the filtered products to the view
            return View("Volunteers", filteredVolunteers);
    }

    public IActionResult Volunteers()
    {
        var allVolunteers = _context.Volunteer.ToList();
        return View(allVolunteers);
    }

        public IActionResult CreateEditVolunteer(int? id)
    {
        if (id != null)
        {
            //editing -> load an expense by id
            var volunteerInDb = _context.Volunteer.SingleOrDefault(volunteer => volunteer.Id == id);
            return View(volunteerInDb);
        }

        return View();
    }

    public IActionResult DeleteVolunteer(int id)
    {
        var volunteerInDb = _context.Volunteer.SingleOrDefault(volunteer => volunteer.Id == id); //find where an id in the Db matches the given id

        _context.Volunteer.Remove(volunteerInDb); //remove that expense from the DB

        _context.SaveChanges();

        return RedirectToAction("Volunteers");
    }

    public IActionResult CreateEditVolunteerForm(Volunteers model)
    {
        if (model.Id == 0)
        {
            //Create
            _context.Volunteer.Add(model);
        }
        else
        {
            //Editing
            _context.Volunteer.Update(model);
        }

        _context.SaveChanges(); //Must be done or else statement above doesnt work

        return RedirectToAction("Volunteers");
    }

    public IActionResult filterVolunteers(string input)
    {
        // Filter products based on category and price range
        var filteredVolunteers = _context.Volunteer.ToList();

        if (input.Equals("All"))
        {
            return RedirectToAction("Volunteers");
        }
        else if (input.Equals("ApprovPend"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => (volunteer.Status == "Approved" || (volunteer.Status == "Pending Approval"))).ToList();
        }
        else if (input.Equals("Approved"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }
        else if (input.Equals("Pending Approval"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }
        else if (input.Equals("Disapproved"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }
        else if (input.Equals("Inactive"))
        {
            filteredVolunteers = filteredVolunteers.Where(volunteer => volunteer.Status == input).ToList();
        }

        // Pass the filtered products to the view
        return RedirectToAction("Volunteers", filteredVolunteers);
        //return View("Volunteers", filteredVolunteers);
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}


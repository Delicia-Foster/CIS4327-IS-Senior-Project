﻿using System;
using Microsoft.EntityFrameworkCore;

namespace CodeBlooded.Models
{
    public class CodeBloodedDbContext : DbContext
    {
        public DbSet<Volunteers> Volunteer { get; set; }
        public DbSet<Opportunities> Opportunities { get; set; }

        public CodeBloodedDbContext(DbContextOptions<CodeBloodedDbContext> options) : base(options)
        {

        }
    }
}


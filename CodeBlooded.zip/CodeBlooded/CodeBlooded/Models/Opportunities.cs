﻿using System;

namespace CodeBlooded.Models
{
    public class Opportunities
    {
        public int Id { get; set; }
        public required string Name { get; set; }
    }
}


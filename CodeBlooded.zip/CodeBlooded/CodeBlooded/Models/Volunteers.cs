﻿using System;


namespace CodeBlooded.Models
{

    public class Volunteers
    {
        public int Id { get; set; }
        public required string Name { get; set; }
        public required string Status { get; set; }
    }
}

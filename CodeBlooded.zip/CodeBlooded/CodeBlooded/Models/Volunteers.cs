﻿using System;


namespace CodeBlooded.Model
{

    public class Volunteers
    {

        //needs getters and setters
        public string Name { get; set; }
       
        //Return info about employee
        public override string ToString()
        {
            string Info = ("Name: " + Name);
            return Info;
        }

    }
}

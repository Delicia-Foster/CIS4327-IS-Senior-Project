﻿using System;
using Microsoft.AspNetCore.Mvc.RazorPages;
using CodeBlooded.Model;

namespace CodeBlooded.Views
{
    public class VolunteersModel : PageModel
    {

        public List<Volunteers> vol { get; set; } = new List<Volunteers>();

        public void OnGet()
        {
            vol.Add(new Volunteers { Name = "James Smith"});
            vol.Add(new Volunteers { Name = "Candy Apple"});
            vol.Add(new Volunteers { Name = "Todd Jones"});
            vol.Add(new Volunteers { Name = "Edgar Allan"});
            vol.Add(new Volunteers { Name = "Mary Bush"});
        }
    }


}


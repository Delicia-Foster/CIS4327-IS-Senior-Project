﻿using System.ComponentModel.DataAnnotations;

namespace CodeBlooded.Models
{
    public class Volunteers
    {
        public int Id { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        public string PreferredCenters { get; set; }

        public string SkillsInterests { get; set; }

        public string AvailabilityTimes { get; set; }

        public string Address { get; set; }

        [RegularExpression(@"^\d{10}$", ErrorMessage = "Home phone must be exactly 10 digits.")]
        public string HomePhone { get; set; }

        [RegularExpression(@"^\d{10}$", ErrorMessage = "Work phone must be exactly 10 digits.")]
        public string WorkPhone { get; set; }

        [RegularExpression(@"^\d{10}$", ErrorMessage = "Cell phone must be exactly 10 digits.")]
        public string CellPhone { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        public string EducationalBackground { get; set; }

        public string CurrentLicenses { get; set; }

        public string EmergencyContactName { get; set; }

        [RegularExpression(@"^\d{10}$", ErrorMessage = "Emergency contact home phone must be exactly 10 digits.")]
        public string EmergencyContactHomePhone { get; set; }

        [RegularExpression(@"^\d{10}$", ErrorMessage = "Emergency contact work phone must be exactly 10 digits.")]
        public string EmergencyContactWorkPhone { get; set; }

        [EmailAddress]
        public string EmergencyContactEmail { get; set; }

        public string EmergencyContactAddress { get; set; }

        public bool DriversLicenseOnFile { get; set; }

        public bool SocialSecurityCardOnFile { get; set; }

        [Required]
        public string Status { get; set; }
        public string FullName
        {
            get
            {
                return $"{FirstName} {LastName}";
            }
        }
    }
}
